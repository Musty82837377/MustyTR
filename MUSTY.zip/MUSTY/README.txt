CMD       1    termux-setup-storage
                
CMD       2    pkg update
                
CMD       3    pkg upgrade
                
CMD       4    git clone https://github.com/SENTOOL/SENTOOL.git
                
CMD       5    cd SENTOOL
               
CMD       6    bash SENTOOL
                
                
________________________________________________



🇴  🇼 🇳 🇪 🇷 @SEN_HACKER


🇴  🇼 🇳 🇪 🇷 @SEN_HACKER



🇴  🇼 🇳 🇪 🇷 @SEN_HACKER



🇴  🇼 🇳 🇪 🇷 @SEN_HACKER



🇴  🇼 🇳 🇪 🇷 @SEN_HACKER



🇴  🇼 🇳 🇪 🇷 @SEN_HACKER